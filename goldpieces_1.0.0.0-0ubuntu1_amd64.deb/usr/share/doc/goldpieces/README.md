GoldPieces
==========
An expandable digital currency for browser based games

GoldPieces?
===========
GoldPieces [GP] are an expandable digital currency to be utilized within the browser based
gaming industries games themselves. Browser based games come in all shapes and sizes but one
common principle they all share is the use of some monetary unit within the games walls. We
think it would add a fun and interesting dimension to the browser gaming industry if the games
took advantage of the blockchain digital currency technology used in the GoldPieces software.

Resources
=========
Website: http://gpieces.com
GitHub:  http://github.com/GoldPieces/GoldPieces
